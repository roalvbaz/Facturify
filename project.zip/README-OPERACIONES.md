# README de Operaciones · FacturON / Facturify

> 📌 **Archivo LOCAL de operaciones**: está añadido a `.gitignore`, NO se commitea ni sube a GitHub.
> Es tu manual personal: qué hace cada cosa, cómo arreglar cualquier problema y cómo personalizar cada pantalla.

---

## Índice

1. [Qué es esto (resumen rápido)](#1-qué-es-esto)
2. [Arquitectura y mapa de carpetas](#2-arquitectura-y-mapa-de-carpetas)
3. [Arranque y variables de entorno](#3-arranque-y-variables-de-entorno)
4. [Base de datos (migraciones manuales)](#4-base-de-datos)
5. [Veri\*factu AEAT — flujo completo](#5-verifactu-aeat)
6. [Cómo gestionar problemas (tabla de diagnóstico)](#6-cómo-gestionar-problemas)
7. [Personalizar cada pantalla](#7-personalizar-cada-pantalla)
8. [Colores y modo oscuro](#8-colores-y-modo-oscuro)
9. [Seguridad, auditoría y rate limiting](#9-seguridad)
10. [Checklist de despliegue](#10-checklist-de-despliegue)

---

## 1. Qué es esto

SaaS español de facturación B2B con cumplimiento **Veri\*factu (RD 1007/2023)**. Una "empresa" factura con su propio certificado digital, y cada factura se encadena por hash (SHA-256), se firma y se envía a la AEAT vía SOAP.

**Stack principal:**

| Capa        | Tecnología                                              |
|-------------|---------------------------------------------------------|
| Framework   | Next.js 16 (App Router) + **Turbopack**, bajo `src/`    |
| React       | 19                                                        |
| Auth        | Supabase Auth (`@supabase/ssr`)                          |
| BD          | PostgreSQL (Supabase) + **Drizzle ORM** (`postgres` driver) |
| Storage     | Supabase Storage (logos, tickets)                        |
| Email       | nodemailer + Gmail                                        |
| Anti-bot    | Google reCAPTCHA v2                                       |
| Cifrado PFX | AES-256-GCM (node:crypto)                                |
| Certificados| node-forge (parsing PFX/P12)                              |
| PDF factura | @react-pdf/renderer (vista previa en el visor)            |
| Gráficas    | chart.js + react-chartjs-2                                 |
| Dark mode   | next-themes + variables CSS                               |

> ⚠️ **Esta Next.js NO es la estándar.** La middleare se llama **`src/proxy.ts`** (exporta `proxy`, no `middleware`), y `searchParams`/`params` son **Promesas** (hay que `await`). Antes de escribir código Next, lee los guides en `node_modules/next/dist/docs/`.

---

## 2. Arquitectura y mapa de carpetas

```
src/
├── app/
│   ├── proxy.ts                 ← middleare de Next 16 (protección de rutas + CSRF)
│   ├── page.tsx                 ← landing pública
│   ├── login/ registro/ recuperar-password/ actualizar-password/
│   ├── empresas/                ← onboarding "Mis Empresas" (layout propio, sidebar en el layout)
│   ├── (dashboard)/             ← grupo con sidebar compartido
│   │   ├── layout.tsx           ← Sidebar + <main>{children}</main>
│   │   ├── dashboard/           ← métricas e ingresos (IngresosChart)
│   │   ├── nueva-factura/       ← editor de factura + productos/clientes
│   │   ├── historial/           ← listado de facturas, badges Veri*factu, visor PDF, rectificativas
│   │   ├── clientes/ productos/ gastos/
│   │   ├── configuracion/       ← empresa, plantilla, color, certificado PFX + entorno AEAT
│   │   └── invitaciones/        ← solo ADMIN_EMAILS
│   └── api/
│       ├── auth/ (login, register, callback)
│       ├── admin/invite         ← web marketing (x-admin-secret)
│       ├── cron/payment-reminders (x-cron-secret) y cron/verifactu (Bearer VERIFACTU_CRON_SECRET)
│       ├── verifactu/status/[invoiceId]
│       └── invoices/export      ← CSV
├── actions/                     ← todas las "server actions" (safe: empresa, factura, cliente...)
├── components/                  ← componentes client
├── db/schema.ts                 ← ÚNICO origen de verdad del esquema
├── lib/
│   ├── verifactu/               ← certificate, cipher, canonical, qr, xml/, soap/, queue/
│   ├── email/ audit.ts rateLimit.ts invitations.ts recaptcha.ts
│   ├── invoice-templates.ts     ← plantillas de factura (ID de plantilla)
│   └── pdf/pdf.ts               ← generación/descarga de PDF (jsPDF sobre el DOM)
drizzle/                          ← migraciones antiguas aplicadas a mano (0000…0002)
supabase/                         ← SQLs sueltos + supabase/migrations/ (MASTER_SCHEMA.sql incluido)
```

**Regla de oro del modelo:** los importes se guardan en **céntimos** (`*_cents` → `integer`). NUNCA uses `float`. Si tocas precios/impuestos, respeta esta convención.

**Constricción de identidad:** el **`company_id` jamás debe aparecer** en URLs ni en la UI al usuario. Todo el filtrado por empresa se hace en el servidor con `getActiveCompanyId()` (cookie `active_company_id`, validada contra `company_members`).

---

## 3. Arranque y variables de entorno

### Instalar y arrancar

```bash
npm ci          # esp. en worktrees: Turbopack rechaza symlinks de node_modules → siempre npm ci
cp .env.example .env   # y rellena los valores
npm run dev      # http://localhost:3000 (Turbopack)
npm run build    # build de producción
npx tsc --noEmit # chequeo de tipos (rápido si algo "no compila")
```

### Variables de entorno (ver `.env.example`)

| Variable | Para qué |
|---|---|
| `DATABASE_URL` / `DIRECT_URL` | conexión postgres de Supabase |
| `NEXT_PUBLIC_SUPABASE_URL` / `ANON_KEY` | cliente público Auth/Storage |
| `SUPABASE_SERVICE_ROLE_KEY` | registros invitados (admin de Auth) |
| `NEXT_PUBLIC_SITE_URL` | base para enlaces de invitación por email |
| `EMAIL_USER` / `EMAIL_PASS` | Gmail emisor + **contraseña de aplicación** (nunca la de la cuenta) |
| `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` / `RECAPTCHA_SECRET_KEY` | reCAPTCHA v2 login/registro |
| `ADMIN_INVITE_SECRET` | header `x-admin-secret` de `/api/admin/invite` |
| `CRON_SECRET` | header `x-cron-secret` de `/api/cron/payment-reminders` |
| `ADMIN_EMAILS` | quién ve `/invitaciones` (separados por comas) |
| `AEAT_ENVIRONMENT` | entorno por defecto de nuevas empresas |
| `CERT_ENCRYPTION_KEY` | **AES-256 (32 bytes hex) para cifrar los PFX**. `openssl rand -hex 32`. Si cambias la clave, los certificados guardados se vuelven ilegibles |
| `VERIFACTU_CRON_SECRET` | header `Authorization: Bearer …` de `/api/cron/verifactu` |
| `SANDBOX_PFX_PATH/BASE64/PASSWORD`, `SANDBOX_NIF_EMISOR` | certificado de pruebas (script `scripts/test-sandbox.ts`) |

---

## 4. Base de datos

**No hay runner de migraciones.** Las tablas se aplican a mano en el SQL editor de Supabase. El flujo correcto:

1. Editas `src/db/schema.ts` (el schema original de Drizzle).
2. Escribes un `.sql` (añádelo en `supabase/migrations/` o `drizzle/`).
3. Lo ejecutas tú en Supabase → SQL Editor.

**Ficheros SQL existentes:** `drizzle/0000_invitations.sql`, `drizzle/0001_audit_immutable.sql` (índices + trigger anti-modificación de audit_logs), `drizzle/0002_security_counters.sql`, `supabase/MASTER_SCHEMA.sql` (esquema completo relanzable), `supabase/migrations/*.sql` (template_id, aeat_cert_per_company, verifactu_submissions), `supabase/security-fixes.sql`, `supabase/enable-rls.sql`.

### Tablas (todas en `src/db/schema.ts`)

| Tabla | Qué guarda | Notas |
|---|---|---|
| `companies` | empresa fiscal | `tax_id` único; p.ej. `verifactu_enabled`, `fiscal_config` |
| `company_members` | usuarios de cada empresa | rol `OWNER/ADMIN/MEMBER`; unicidad (company, user) |
| `customers` | clientes | por empresa |
| `invoice_series` | correlativos por (empresa, serie, año) | guarda `last_hash` para encadenar |
| `invoices` | facturas | serie + nº + `formatted_number` ("F-2026-0001"), `prev_hash/current_hash/canonical_string/qr_code_url`, importes en cént, `is_locked` |
| `invoice_lines` | líneas de factura | |
| `expenses` | gastos/compras | `vat_percent`, `irpf_percent`, importes en cént, `receipt_url` |
| `estimates` / `estimate_lines` | presupuestos | (tabla preparada) |
| `audit_logs` | auditoría inmutable | `event_code`, `description`, `metadata`, `ip_address` |
| `security_counters` | rate limiting | PK (key, action, window_start) |
| `products` | catálogo | `price_cents`, `default_vat` |
| `company_settings` | visual + certificado | `theme_color`, `template_id`, `font_family`, `logo_url`, **`aeat_pfx_data` / `aeat_pfx_password` cifrados**, `aeat_environment`, validez del cert |
| `invitations` | invitaciones de registro | token_hash SHA-256, expira a los 7 días |
| `verifactu_submissions` | cola de envío AEAT | estado, intentos, backoff, `csv`, `aeat_response` |

---

## 5. Veri\*factu AEAT

### El flujo, de principio a fin

```
1. Crear factura (nueva-factura)
   → invoice.actions: valida, calcula importes (céntimos), asigna serie+número
     (invoice_series.last_number+1), calcula encadenamiento SHA-256
     (prev_hash → current_hash + canonical_string), genera QR (lib/verifactu/qr.ts),
     escribe invoices + invoice_lines (is_locked=true) y crea audit_log.
2. Se encola en verifactu_submissions
   → estado PENDIENTE, operation ALTA (y ANULACION para rectificativas), xml_body listo.
3. Cron /api/cron/verifactu (cada ~60 s)
   → Authorization: Bearer $VERIFACTU_CRON_SECRET
   → processor.processQueue(20):
        a) markAsSending  (PENDIENTE → ENVIADO: bloquea duplicados)
        b) descifra el PFX de la empresa (AES-256-GCM) → parsePfx → agente TLS cliente
        c) submitToVerifactu (SOAP al endpoint sandbox/producción)
        d) ¿success?   → CONFORME + CSV
           ¿reintentable y quedan intentos? → PENDIENTE + backoff [1,5,15,60,240] min
           ¿no?        → NO_CONFORME (respuesta no conforme) o ERROR (permanente/agotado).
4. El historial muestra el estado con el badge Veri*factu (consulta /api/verifactu/status/[invoiceId]). La factura imprime su QR y el CSV en el PDF.
```

### Certificados (CADA empresa sube el suyo)

- En **Configuración** cada empresa sube su PFX/P12 + contraseña. Se valida el PFX "en seco" antes de persistir (parseo + vigencia): no se guardan certificados corruptos ni caducados.
- Se cifra con **AES-256-GCM** usando `CERT_ENCRYPTION_KEY` (`lib/verifactu/cipher.ts`) y se guarda en `company_settings.aeat_pfx_data` / `aeat_pfx_password`. La contraseña también va cifrada.
- El entorno (sandbox/producción) es **por empresa** (`aeat_environment`). El selector en Configuración lo cambia al momento sin borrar el certificado.
- Endpoints (`lib/verifactu/soap/endpoints.ts`):
  - sandbox: `https://preapiw.aeat.es/wlPL/SGFACB13UL/ProxyAplicacion/ProxyService`
  - producción: `https://sede.agenciatributaria.gob.es/wlPL/SGFACB13UL/ProxyAplicacion/ProxyService`
- Si una empresa no tiene PFX y tiene facturas pendientes, el procesador marca **ERROR** con el mensaje "no tiene certificado digital configurado".

### Estados de la cola

| Estado | Significado |
|---|---|
| `PENDIENTE` | esperando envío (o reintento programado) |
| `ENVIADO` | en proceso ahora mismo (bloqueo anti-duplicado) |
| `CONFORME` | AEAT aceptó; `csv` = Código Seguro de Verificación |
| `NO_CONFORME` | AEAT devolvió rechazo (se guarda `aeat_response`) |
| `ERROR` | error permanente (cert, configuración, o agotó los `max_attempts`=5) |

**Truco de diagnóstico rápido:** lista de envíos de una empresa en Supabase:
```sql
select f.formatted_number, s.status, s.attempts, s.last_error, s.created_at, s.updated_at
from verifactu_submissions s
join invoices f on f.id = s.invoice_id
where s.company_id = '<company_id>'
order by s.created_at desc limit 50;
```

---

## 6. Cómo gestionar problemas

### Escenario A — El build rompe con `Expression expected … <<<<<<< HEAD`

Síntoma: en la línea que apunta hay un `<<<<<<< HEAD`. Significa que se commiteó un **conflicto de merge sin resolver**.

```bash
# Encontrar TODOS los ficheros con marcadores:
git grep -n -E '^(<<<<<<<|=======|>>>>>>>)' -- '*.ts' '*.tsx'
# Y el diff exacto por fichero:
git show HEAD:src/components/sidebar.tsx | grep -n '<<<<<<<'
```

Resolver: quedarte con el lado **HEAD** (main) en cada fichero, borrar las 3 líneas de marcadores, y **verificar con `npx tsc --noEmit`**. No olvides revisar también localmente `git diff --check` (detecta "whitespace errors" y marcadores). Regla: si el conflicto es de diseño UI, main es la versión mantenida; si la rama es una feature nueva y aporta algo concreto (como `data-label="Acciones"`), cómbinalo a mano.

### Escenario B — "No compila" / error de tipos

```bash
npx tsc --noEmit
```
Incluye el fichero y la línea del error. Causas comunes:
- Import huérfano tras resolver un merge (falta `audit_logs` etc. en `import … from '@/db/schema'`).
- Referencias a un componente con otro nombre.
- `searchParams`/`params` usados sin `await` (en esta Next son Promesas).

### Escenario C — Error de Turbopack con symlink/junction en un worktree

Turbopack rechaza `node_modules` apuntando fuera de la raíz del worktree. **Solución: `npm ci` dentro del worktree** (nunca copiar el `.next` ni enlazar).

### Escenario D — El login falla aunque las credenciales son correctas

- Rate limiting: `security_counters` bloquea login tras **5 fallos / 15 min** (clave `LOGIN_FAILED`). El registro `USER_LOGIN_FAILED` queda en `audit_logs`. Espera o borra la fila del contador en Supabase para desbloquear en dev.
- Mira las claves reCAPTCHA: si `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` no coincide con `RECAPTCHA_SECRET_KEY`, el verificado falla.
- Comprueba `NEXT_PUBLIC_SUPABASE_URL/ANON_KEY`: si no son del proyecto correcto, la sesión no se crea.

### Escenario E — No llegan los emails de invitación

- Usa **contraseña de aplicación de Gmail** en `EMAIL_PASS` (2FA activa impide la contraseña normal).
- El enlace de la invitación caduca a los **7 días** (`invitations.expires_at`) y usa `NEXT_PUBLIC_SITE_URL`. Si el e-mail llega con un dominio raro, esa var está mal.
- Estados útiles: `ENVIADA` → `REGISTRADA` → `CANCELADA` (ver `status` en `invitations`).

### Escenario F — Un envío Veri\*factu queda en ERROR/NO_CONFORME

1. Consulta el registro en `verifactu_submissions` (ver SQL en §5): mira `last_error`, `attempts`, `status`.
2. Errores "certificado"/"pfx" → el PFX de esa empresa es inválido o caducó, o falta (¿se borró `CERT_ENCRYPTION_KEY`?). **No se reintentan** (son errores de configuración, no de red).
3. "HTTP 404/502/503", "socket", "econnreset", "timeout" → reintentables; el cron los volverá a intentar con backoff.
4. `NO_CONFORME` → la AEAT rechaza el registro: lee `aeat_response` (códigos de error AEAT) y corrige los datos fiscales.
5. ¿Nada progresa? Dispara el cron manualmente:
   ```bash
   curl -H "Authorization: Bearer $VERIFACTU_CRON_SECRET" http://localhost:3000/api/cron/verifactu
   ```
   Debería responder `{ok:true, processed, successes, retries, errors}`.

### Escenario G — El PDF no se descarga / se ve vacío

- El PDF del visor se genera sobre el DOM con `lib/pdf/pdf.ts` (jsPDF). Abre el visor completo (icono de ojo) antes de descargar.
- Si falla en producción, comprueba que logotipos/imágenes están en Supabase Storage con URL pública.
- `@react-pdf/renderer` (vista previa PDF) puede dar problemas de fuentes en Windows dev; no afecta al build.

### Escenario H — Cambios que no se ven tras guardar

Es caché de Next. Las server actions usan `revalidatePath`. Si editas UI y no se refleja: `npm run dev` recarga solo; en producción, buildea de nuevo (`npm run build`).

### Escenario I — El sidebar se duplica o el usuario nuevo no ve su empresa

- `/empresas` vive **fuera** del layout `(dashboard)` (evita un bucle de redirección). Su sidebar lo pinta su **propio** `empresas/layout.tsx`. Si la página de empresas renderiza además un `DashboardShell`, aparece duplicado: la página debe devolver solo contenido.
- Un usuario nuevo sin empresa entra en `/empresas` para crear la primera (onboarding). Tras crear, `setActiveCompanyId` guarda la cookie y ya ve el dashboard.

### Escenario J — Audit_logs invalidado

Está protegido por un trigger (`trg_prevent_audit_logs_mutation`) que impide UPDATE/DELETE. Si necesitas limpiar logs en dev, TRUNCA la tabla dentro de un bloque `BEGIN … set session_replication_role = replica; truncate table audit_logs; reset; COMMIT;`. **En producción no tocar.**
El único punto de escritura de audit es `lib/audit.ts` (`logAuditEvent`) — no insertes `audit_logs` en otro sitio.

---

## 7. Personalizar cada pantalla

> Patrón general: cada text, etiqueta o color que veas con un hex literal (`#…`) en un componente es candidato a ser "tema". Para cambiar un texto: busca la cadena en el fichero indicado. Para cambiar un color que ahora es fijo, sustitúyelo por una variable de `globals.css` (ver §8) o por el hex que quieras.

### Landing — `src/app/page.tsx`
Solo una página de aterrizaje. Textos y precios van hardcodeados ahí. Para enlazarla bien, el botón "Entrar" apunta a `/login`.

### Login / Registro / Recuperar / Actualizar contraseña
- `src/app/login/page.tsx`, `src/app/registro/page.tsx`, `src/app/recuperar-password/page.tsx`, `src/app/actualizar-password/page.tsx`.
- Los formularios client son `src/components/registerForm.tsx` (incluye reCAPTCHA y texto de corte legal vía `declaracionResponsable.tsx`).
- Flujo de registro invitado: el enlace es `/registro?invite=<token>`; exige `ADMIN_EMAILS` para que el admin cree la invitación desde `/invitaciones`. Cambios de textos/copy: busca en `registerForm.tsx` y en los `page.tsx`.

### Sidebar — `src/components/sidebar.tsx`
- Colores del sidebar están hardcodeados a propósito (tema oscuro fijo): busca `#080f1a` (fondo), `#0ea5e9`/`#38bdf8` (azul activo), `#94a3b8` (texto).
- Para añadir un enlace de menú: añade un `<Link href="…">` en la sección que toque (Principal / Directorio / Empresa). IMPORTANTE: la ruta debe existir y estar protegida (ver `src/proxy.ts:60` lista de públicas).
- `ThemeToggle` (sol/luna) está arriba a la derecha, junto al engranaje de Configuración.

### Dashboard — `src/app/(dashboard)/dashboard/page.tsx` + `src/components/ingresosChart.tsx`
- Las tarjetas de métricas vienen del array `metrics` (fila ~125): cada una tiene `label`, `value`, `icon` (clases `fa-…` de FontAwesome) y colores `borderColor`/`iconBg`/`iconColor`. Edítalas ahí.
- "Evolución de Ingresos" usa chart.js (`ingresosChart.tsx`). El grid `2fr 1fr` se ajusta en el mismo `page.tsx`.

### Nueva factura — `src/app/(dashboard)/nueva-factura/page.tsx`
- Bordado con `customerSelector.tsx` (cliente), `productCatalogSelector.tsx` (líneas desde catálogo), cálculo de importes y botones de guardar.
- Modo rectificación: llega con `?mode=rectification` y datos en `sessionStorage.FacturON_rectification_data` (el modal del historial lo construye). Serie `R` + conceptos en negativo.
- Personaliza textos de ayuda, IVA por defecto, y redondeo en este mismo fichero.

### Historial — `src/app/(dashboard)/historial/page.tsx` + componentes
- Tabla/lista: `invoiceTableClient.tsx` (badge Veri*factu, serie, filtros, acciones). El badge de estado AEAT se pinta con `VerifactuBadge` dentro de una celda `<td>`.
- Visor de factura/PDF y envío por email: `invoiceModalClient.tsx` (variantes icon / preview-only / confirm-emit; botón "Rectificar" que abre el modal `showRectifyConfirm`).
- Columna "Ticket": `invoiceTableClient.tsx`.

### Gastos — `src/app/(dashboard)/gastos/page.tsx` + `expensesClientView.tsx` + `newExpenseModal.tsx`
- Vista lista/filtros/totales: `expensesClientView.tsx`; aquí viven las tarjetas "Total Gastos", "Base Imponible" e "IVA Soportado".
- **Modal "Registrar Gasto / Compra": `newExpenseModal.tsx`.** Campos: proveedor, NIF, ref, fecha, categoría, descripción, Base/IVA/IRPF (bloque con recálculo en vivo), método de pago, estado y adjuntar ticket. El array de categorías está en los `<option>` de ese fichero (y en `expensesClientView.tsx` para los filtros): cambia ambos si añades una categoría.
- Importes: `subtotal_cents`, `vat_amount_cents`, `irpf_amount_cents`, `total_cents`.

### Clientes y Productos — `…/clientes/page.tsx`, `…/productos/page.tsx`
- Tablas + formularios CRUD con actions `customer.actions.ts` y `product.actions.ts`. Botones de borrado: `deleteCustomerButton.tsx`, `deleteProductButton.tsx`.
- Catálogo (para rellenar líneas de factura): `productCatalogSelector.tsx` (llamada desde nueva-factura).

### Configuración — `src/app/(dashboard)/configuracion/page.tsx` + `configForm.tsx`
- La page pasa a `ConfigForm` un objeto `mergedData = {…company, …settings}` (las settings pisan: `theme_color`, `template_id`, `logo_url`, y **`aeat_environment`**).
- **Plantilla de factura**: `templateSelector.tsx` + `templatePreview.tsx` leen `src/lib/invoice-templates.ts` (definiciones de plantillas, IDs). Para añadir plantilla: define el ID allí y úsalo en `InvoicePDFTemplate`. `company_settings.template_id` guarda la elección.
- **Color de la empresa**: entrada de color que usa `colorUtils.ts` (contrast) — se aplica a la plantilla de factura.
- **Certificado y entorno AEAT**: bloque "Certificado Digital AEAT" del `configForm.tsx`:
  - Selector segmentado Sandbox/Producción (persiste con `updateAeatEnvironmentAction` si hay certificado, o en el propio guardado de PFX).
  - Drag & drop del `.pfx/.p12` + campo de contraseña con ojo; valida tamaño ≤3 MB y extensión.
  - Con certificado ya subido: botones "Subir nuevo certificado" (sustitución inline) y "Eliminar certificado".

### Empresas (Mis Empresas / onboarding) — `src/app/empresas/page.tsx` + `empresasManager.tsx`
- Tarjetas de empresas con selector de activa; onboarding cuando `companies.length === 0` (crea primera empresa → cookie `active_company_id`).
- Su layout propio está en `src/app/empresas/layout.tsx` (no hereda el Sidebar del dashboard).

### Invitaciones — `src/app/(dashboard)/invitaciones/page.tsx` + `invitationsManager.tsx`
- Solo visible para `ADMIN_EMAILS` (se pasa `isAdmin` desde el layout). Añadir email → genera enlace → email. Botones "Copiar enlace" y "Reenviar".
- Estado por invitación: `ENVIADA / REGISTRADA / CANCELADA`.

### PDF de factura — `src/components/invoicePDFTemplate.tsx`
- Es el render de la factura en el visor (`InvoiceModalClient`) y la base del descargable. Personaliza cabecera, colores y pie ahí. El selector de plantilla (`templateId`) ramifica dentro.

---

## 8. Colores y modo oscuro

Las variables de tema viven en **`src/app/globals.css`**: el bloque `:root` define el modo claro y **`.dark` (a partir de la línea ~332)** el oscuro.

| Variable        | Claro      | Oscuro    | Uso típico                      |
|-----------------|-----------:|----------:|----------------------------------|
| `--bg-color`    | `#f8fafc`  | `#0f172a` | fondo de página, inputs, paneles |
| `--card-bg`     | `#ffffff`  | `#1e293b` | tarjetas, modales                 |
| `--text-color`/`--text-main` | `#1e293b` | `#f1f5f9` | textos principales |
| `--text-muted`  | `#64748b`  | `#94a3b8` | subtítulos, etiquetas, placeholders |
| `--border-color`| `#e2e8f0`  | `#334155` | bordes                             |
| `--primary` / `--primary-hover` | indigo | — | botones principales |

Reglas prácticas:
- **Nunca** pongas `color: '#0f172a'`, `#334155`, `#475569`, `#64748b`, `FFFFFF` de fondo en un componente si quieres que respete el tema → usa las variables.
- Los **acentos semánticos** pueden quedarse fijos si leen bien en ambos: verde IVA usa `#10b981`, blanco de botón `#ffffff`, rojo de borrado `#ef4444`. Un verde oscuro como `#059669` solo se ve bien en claro: en oscuro se pierde.
- El sidebar es **deliberadamente oscuro** (no cambia con el tema).
- El modo oscuro del cliente lo controla `next-themes` (botón sol/luna en el sidebar). `ThemeToggle` decide claro/oscuro; con "system" respeta el SO.

Para buscar colores fijos que rompan el modo oscuro en cualquier pantalla: `git grep -n -E '#[0-9a-fA-F]{6}' src/ | grep -v globals.css` y revisa cada coincidencia.

---

## 9. Seguridad

- **Auditoría**: `src/lib/audit.ts` (`logAuditEvent`, códigos tipados). Eventos: login (incl. `USER_LOGIN_FAILED`), registro, passwords, CRUD de empresa/cliente/producto/gasto/factura, email, recordatorios, invitación, export CSV, cron. **No construyas una pantalla de auditoría en la app**: se revisa en Supabase.
- **Rate limiting**: `src/lib/rateLimit.ts` + tabla `security_counters`. Límites: login 5 fallos/15 min, OTP 3 envíos/30 min, OTP 5 verificaciones/15 min, invitaciones admin 20/IP/60 min.
- **CSRF**: `proxy.ts` inyecta `X-CSRF-Token` en cada respuesta.
- **Headers**: el proxy borra `X-Powered-By` y `Server`.
- **Certificados PFX**: cifrados AES-256-GCM, nunca salen del servidor; la acción de "info" del certificado solo devuelve subject/validez, nunca el PFX ni la contraseña.
- **Roles**: `company_members.role` (`OWNER/ADMIN/MEMBER`); solo administradores ven invitaciones.

---

## 10. Checklist de despliegue

**Build:**
- [ ] `npx tsc --noEmit` sin errores y `npm run build` OK (en CI/worktrees: `npm ci` primero por el tema Turbopack).

**Entorno (Render o similar):**
- [ ] Todas las variables de §3 configuradas, especialmente `VERIFACTU_CRON_SECRET`, `CRON_SECRET`, `ADMIN_INVITE_SECRET`, `CERT_ENCRYPTION_KEY`.
- [ ] npm script de arranque: `next start`.

**Crons (disparar externamente o Render Cron Jobs):**
- [ ] `GET /api/cron/verifactu` cada ~60 s → header `Authorization: Bearer $VERIFACTU_CRON_SECRET`.
- [ ] `GET /api/cron/payment-reminders` (frecuencia a tu elección) → header `x-cron-secret: $CRON_SECRET`.

**AEAT:**
- [ ] Las empresas reales suben su PFX de producción desde Configuración y marcan entorno **Producción**.
- [ ] Prueba previa: script `scripts/test-sandbox.ts` con el certificado de pruebas (`SANDBOX_PFX_*`) + `scripts/make-test-cert.ts` para generar certificados de test.
- [ ] Tras el primer envío conforme, guarda el CSV: es la prueba del envío a la AEAT.

**Post-despliegue:**
- [ ] Migraciones SQL aplicadas a mano en Supabase (no hay runner).
- [ ] Verifica un ciclo completo: factura → cola → cron → `CONFORME` + CSV.