'use client';

import { useState, useEffect, type CSSProperties } from 'react';
import InvoiceModalClient from '@/components/invoiceModalClient';
import InvoiceStatusButton from '@/components/invoiceStatusButton';
import { sendPaymentReminderAction } from '@/actions/reminder.actions';
import { showToast } from '@/lib/utils/toast';

interface ColumnConfig {
  id: string;
  label: string;
  defaultVisible: boolean;
}

const AVAILABLE_COLUMNS: ColumnConfig[] = [
  { id: 'number', label: 'Nº Factura', defaultVisible: true },
  { id: 'client', label: 'Cliente & NIF', defaultVisible: true },
  { id: 'dates', label: 'Emisión / Vencimiento', defaultVisible: true },
  { id: 'items', label: 'Conceptos', defaultVisible: false },
  { id: 'breakdown', label: 'Base & IVA', defaultVisible: false },
];

interface VerifactuStatus {
  status?: string | null;
  csv?: string | null;
  last_error?: string | null;
}

/** Badge del estado del envío a la AEAT (Veri*factu) */
function VerifactuBadge({ vf }: { vf?: VerifactuStatus }) {
  if (!vf) {
    return (
      <span style={{ opacity: 0.45, fontSize: '0.75rem', color: 'var(--text-muted)' }} title="Esta factura no se ha enviado a la AEAT">
        —
      </span>
    );
  }
  const status = (vf.status || '').toUpperCase();
  const base: CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '4px',
    fontSize: '0.7rem',
    fontWeight: 700,
    padding: '3px 8px',
    borderRadius: '999px',
    whiteSpace: 'nowrap',
  };

  if (status === 'CONFORME') {
    return (
      <span style={{ ...base, backgroundColor: '#d1fae5', color: '#047857' }} title={`AEAT conforme · CSV: ${vf.csv || '—'}`}>
        ✓ CONFORME
      </span>
    );
  }
  if (status === 'ENVIADO') {
    return (
      <span style={{ ...base, backgroundColor: '#dbeafe', color: '#1d4ed8' }} title="Enviándose ahora mismo a la AEAT">
        ↻ Enviando
      </span>
    );
  }
  if (status === 'PENDIENTE') {
    return (
      <span style={{ ...base, backgroundColor: '#fef3c7', color: '#b45309' }} title="En cola de envío · reintento automático">
        ⏳ En cola
      </span>
    );
  }
  if (status === 'ERROR' || status === 'NO_CONFORME') {
    return (
      <span style={{ ...base, backgroundColor: '#fee2e2', color: '#b91c1c' }} title={vf.last_error || 'Rechazado por la AEAT'}>
        ✕ {status === 'NO_CONFORME' ? 'NO CONFORME' : 'ERROR'}
      </span>
    );
  }
  return (
    <span style={{ ...base, backgroundColor: '#e5e7eb', color: '#374151' }} title={vf.last_error || ''}>
      {status}
    </span>
  );
}

export default function InvoicesTableClient({
  facturas,
  empresa,
  settings,
  templateId,
  verifactuStatus,
}: {
  facturas: any[];
  empresa: any;
  settings?: any;
  templateId?: string;
  verifactuStatus?: Record<string, VerifactuStatus>;
}) {
  const [visibleColumns, setVisibleColumns] = useState<{ [key: string]: boolean }>({});
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [loadingReminderId, setLoadingReminderId] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('FacturON_invoice_columns');
    if (saved) {
      try {
        setVisibleColumns(JSON.parse(saved));
        return;
      } catch (e) {
        console.error(e);
      }
    }
    const initial: { [key: string]: boolean } = {};
    AVAILABLE_COLUMNS.forEach((col) => {
      initial[col.id] = col.defaultVisible;
    });
    setVisibleColumns(initial);
  }, []);

  const toggleColumn = (id: string) => {
    const updated = { ...visibleColumns, [id]: !visibleColumns[id] };
    setVisibleColumns(updated);
    localStorage.setItem('FacturON_invoice_columns', JSON.stringify(updated));
  };

  const isColVisible = (id: string) => visibleColumns[id] !== false;

  const handleSendReminder = async (invoiceId: string, invoiceNumber: string, clientEmail?: string) => {
    if (!clientEmail || !clientEmail.trim()) {
      showToast.error('El cliente no tiene un correo electrónico asociado.');
      return;
    }

    setLoadingReminderId(invoiceId);
    try {
      const res = await sendPaymentReminderAction(invoiceId);
      if (res.success) {
        showToast.success(`Recordatorio de pago enviado para ${invoiceNumber}`);
      } else {
        showToast.error(res.error || 'No se pudo enviar el recordatorio');
      }
    } catch (err: any) {
      showToast.error(err.message || 'Error al procesar el recordatorio');
    } finally {
      setLoadingReminderId(null);
    }
  };

  return (
    <div style={{ position: 'relative' }}>
      {/* Botón selector de columnas con z-index */}
      <div 
        style={{ 
          display: 'flex', 
          justifyContent: 'flex-end', 
          padding: '0.75rem 1.25rem', 
          borderBottom: '1px solid var(--border-color)', 
          backgroundColor: 'var(--bg-color)', 
          position: 'relative',
          zIndex: 30 
        }}
      >
        <button
          type="button"
          onClick={() => setDropdownOpen(!dropdownOpen)}
          className="btn"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            fontSize: '0.8rem',
            padding: '0.4rem 0.8rem',
            backgroundColor: 'var(--card-bg)',
            border: '1px solid var(--border-color)',
            color: 'var(--text-color)',
            cursor: 'pointer',
            borderRadius: '6px',
          }}
        >
          <i className="fas fa-columns" style={{ color: 'var(--primary)' }}></i>
          <span>Personalizar Columnas</span>
        </button>

        {dropdownOpen && (
          <>
            <div
              onClick={() => setDropdownOpen(false)}
              style={{ position: 'fixed', inset: 0, zIndex: 90 }}
            />
            <div
              style={{
                position: 'absolute',
                top: 'calc(100% + 4px)',
                right: '1.25rem',
                width: '240px',
                backgroundColor: 'var(--card-bg)',
                border: '1px solid var(--border-color)',
                borderRadius: '8px',
                boxShadow: '0 12px 24px -4px rgba(0,0,0,0.15)',
                padding: '0.85rem',
                zIndex: 100,
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
              }}
            >
              <span style={{ fontSize: '0.75rem', fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '2px' }}>
                Columnas Visibles
              </span>
              {AVAILABLE_COLUMNS.map((col) => (
                <label
                  key={col.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    fontSize: '0.825rem',
                    color: '#0f172a',
                    cursor: 'pointer',
                    userSelect: 'none',
                  }}
                >
                  <input
                    type="checkbox"
                    checked={isColVisible(col.id)}
                    onChange={() => toggleColumn(col.id)}
                    style={{ accentColor: 'var(--primary)', cursor: 'pointer', width: '15px', height: '15px' }}
                  />
                  {col.label}
                </label>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Tabla */}
      <div style={{ overflowX: 'auto', position: 'relative', zIndex: 10 }}>
        <table className="data-table mobile-card-table">
          <thead>
            <tr>
              {isColVisible('number') && <th>Nº Factura</th>}
              {isColVisible('client') && <th>Cliente & NIF</th>}
              {isColVisible('dates') && <th>Emisión / Vencimiento</th>}
              {isColVisible('items') && <th>Conceptos</th>}
              {isColVisible('breakdown') && <th>Base & IVA</th>}
              
              <th style={{ textAlign: 'right' }}>Total</th>
              <th style={{ textAlign: 'center' }}>Estado</th>
              <th style={{ textAlign: 'center' }}>Veri*factu</th>
              <th style={{ textAlign: 'center' }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {facturas.map((f) => {
              const estado = f.status || 'Pendiente';
              const isPendiente = estado.toLowerCase().includes('pendiente');
              const fechaEmision = f.issued_at ? new Date(f.issued_at).toLocaleDateString('es-ES') : '-';
              const fechaVencimiento = f.due_date ? new Date(f.due_date).toLocaleDateString('es-ES') : '-';
              const base = ((f.subtotal_cents || 0) / 100).toFixed(2);
              const iva = ((f.vat_total_cents || 0) / 100).toFixed(2);
              const total = ((f.total_cents || 0) / 100).toFixed(2);
              const isReminderLoading = loadingReminderId === f.id;

              return (
                <tr key={f.id}>
                  {isColVisible('number') && (
                    <td data-label="Nº Factura">
                      <strong style={{ color: 'var(--primary)', fontSize: '0.9rem' }}>
                        {f.formatted_number}
                      </strong>
                    </td>
                  )}

                  {isColVisible('client') && (
                    <td data-label="Cliente & NIF">
                      <div style={{ fontWeight: 600, color: 'var(--text-color)' }}>
                        {f.client_name || 'Cliente sin nombre'}
                      </div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {f.client_tax_id ? `NIF: ${f.client_tax_id}` : 'Sin NIF'}
                      </span>
                    </td>
                  )}

                  {isColVisible('dates') && (
                    <td data-label="Emisión / Vencimiento">
                      <div style={{ fontSize: '0.85rem', color: 'var(--text-color)' }}>
                        {fechaEmision}
                      </div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        Vence: {fechaVencimiento}
                      </span>
                    </td>
                  )}

                  {isColVisible('items') && (
                    <td data-label="Conceptos" style={{ maxWidth: '200px' }}>
                      <span
                        style={{ fontSize: '0.8rem', color: 'var(--text-color)', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                        title={f.lines?.map((l: any) => l.description).join(', ')}
                      >
                        {f.lines && f.lines.length > 0 ? f.lines[0].description : 'Sin conceptos'}
                      </span>
                      {f.lines && f.lines.length > 1 && (
                        <span style={{ fontSize: '0.7rem', color: 'var(--primary)', fontWeight: 600 }}>
                          +{f.lines.length - 1} conceptos más
                        </span>
                      )}
                    </td>
                  )}

                  {isColVisible('breakdown') && (
                    <td data-label="Base & IVA">
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-color)' }}>
                        Base: {base} €
                      </div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        IVA: +{iva} €
                      </span>
                    </td>
                  )}

                  <td data-label="Total" style={{ textAlign: 'right' }}>
                    <strong style={{ fontSize: '1rem', color: 'var(--text-color)' }}>
                      {total} €
                    </strong>
                  </td>

                  <td data-label="Estado" style={{ textAlign: 'center' }}>
                    <InvoiceStatusButton invoiceId={f.id} initialStatus={estado} />
                  </td>

<td style={{ textAlign: 'center' }}>
                    <VerifactuBadge vf={verifactuStatus?.[f.id]} />
                  </td>

                  <td data-label="Acciones" style={{ textAlign: 'center' }}>
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
                      {isPendiente && (
                        <button
                          type="button"
                          onClick={() => handleSendReminder(f.id, f.formatted_number, f.client_email)}
                          disabled={isReminderLoading}
                          title="Enviar correo de recordatorio de vencimiento al cliente"
                          style={{
                            background: '#fef3c7',
                            border: '1px solid #fde68a',
                            color: '#b45309',
                            cursor: isReminderLoading ? 'not-allowed' : 'pointer',
                            fontSize: '0.85rem',
                            padding: '6px 8px',
                            borderRadius: '6px',
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <i className={`fas ${isReminderLoading ? 'fa-spinner fa-spin' : 'fa-bell'}`}></i>
                        </button>
                      )}

                      <InvoiceModalClient factura={f} empresa={empresa} settings={settings} templateId={templateId} />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}