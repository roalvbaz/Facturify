/**
 * Generación del PDF de factura EN EL SERVIDOR con @react-pdf/renderer.
 *
 * POR QUÉ: la vía anterior (html2pdf.js + html2canvas dentro de un iframe)
 * dependía de un CDN externo y del parseo de colores modernos (oklch/lab),
 * con lo que podía colgarse o fallar según la red y el navegador. Aquí el PDF
 * se dibuja como vectores puros desde los datos de la factura: sin DOM, sin
 * CDN y sin html2canvas → el render nunca se cuelga ni revienta con colores.
 *
 * Uso (server-only): `renderInvoicePdfBuffer({ factura, empresa, settings })`
 */

import {
  Document,
  Page,
  View,
  Text,
  StyleSheet,
  Image,
  renderToBuffer,
} from '@react-pdf/renderer';
import QRCode from 'qrcode';

// ─────────────────────────────────────────────────────────────
// Tiny helpers
// ─────────────────────────────────────────────────────────────

function eur(cents: number | string | null | undefined): string {
  const n = Math.round(Number(cents) || 0);
  return `${(n / 100).toFixed(2)} €`;
}

function fmtDate(d: Date | string | null | undefined): string {
  if (!d) return '-';
  const date = d instanceof Date ? d : new Date(d);
  if (Number.isNaN(date.getTime())) return '-';
  return date.toLocaleDateString('es-ES');
}

function isRectification(factura: any): boolean {
  return (
    factura?.series_code === 'R' ||
    String(factura?.formatted_number || '').startsWith('R-') ||
    Boolean(factura?.rectifies_invoice_id)
  );
}

/** Sube a base64(data URI) un logotipo remoto; si falla, devuelve null. */
async function embedLogo(url: string | null | undefined): Promise<string | null> {
  if (!url) return null;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 6000);
    const res: any = await fetch(url, { signal: ctrl.signal });
    clearTimeout(timer);
    if (!res?.ok) return null;
    const buffer = Buffer.from(await res.arrayBuffer());
    const mime = res.headers.get('content-type')?.split(';')[0]?.trim() || 'image/png';
    return `data:${mime};base64,${buffer.toString('base64')}`;
  } catch {
    return null; // sin logo no se rompe el PDF
  }
}

/** QR de la factura como data URI (local, sin CORS ni red externa). */
async function buildQrDataUri(value: string | null | undefined): Promise<string | undefined> {
  if (!value) return undefined;
  try {
    return await QRCode.toDataURL(value, { width: 176, margin: 1 });
  } catch {
    return undefined;
  }
}

// ─────────────────────────────────────────────────────────────
// Layout
// ─────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  page: { padding: 34, fontFamily: 'Helvetica', color: '#0f172a' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 16,
    borderRadius: 4,
    marginBottom: 12,
  },
  headerRight: { alignItems: 'flex-end' },
  headerLabel: { fontWeight: 'bold', fontSize: 17, marginBottom: 4 },
  headerMeta: { fontSize: 9, opacity: 0.9, lineHeight: 1.4 },
  logo: { maxHeight: 34, maxWidth: 140, marginBottom: 5, objectFit: 'contain' },
  rectBox: {
    flexDirection: 'row',
    backgroundColor: '#fef2f2',
    border: 1,
    borderColor: '#fecaca',
    borderRadius: 4,
    padding: 8,
    marginBottom: 12,
  },
  rectTitle: { fontSize: 8, fontWeight: 'bold', color: '#dc2626', textTransform: 'uppercase' },
  rectText: { fontSize: 9, color: '#7f1d1d', marginTop: 2 },
  clientBox: {
    flexDirection: 'row',
    backgroundColor: '#f8fafc',
    borderLeftWidth: 4,
    borderLeftColor: '#4f46e5',
    padding: 10,
    marginBottom: 14,
  },
  clientLabel: { fontSize: 7.5, fontWeight: 'bold', color: '#64748b', textTransform: 'uppercase', marginBottom: 2 },
  clientName: { fontSize: 12, fontWeight: 'bold', color: '#0f172a', marginBottom: 2 },
  clientMeta: { fontSize: 9.5, color: '#475569' },
  table: { width: '100%', marginBottom: 14 },
  th: {
    padding: 5,
    fontSize: 8.5,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'left',
  },
  thR: { textAlign: 'right' },
  thC: { textAlign: 'center' },
  td: { padding: 5, fontSize: 9.5, color: '#0f172a', borderBottomWidth: 0.5, borderBottomColor: '#f1f5f9' },
  tdR: { textAlign: 'right' },
  tdC: { textAlign: 'center' },
  tdMut: { color: '#475569' },
  tdBold: { fontWeight: 'bold' },
});

interface TotalsRow {
  label: string;
  value: string;
}

function buildTotals(factura: any): TotalsRow[] {
  const rows: TotalsRow[] = [{ label: 'Base Imponible', value: eur(factura.subtotal_cents) }];
  rows.push({ label: 'IVA Repercutido', value: eur(factura.vat_total_cents) });
  if (Number(factura.irpf_total_cents) > 0) {
    rows.push({ label: 'Retención IRPF', value: `-${eur(factura.irpf_total_cents)}` });
  }
  rows.push({ label: 'TOTAL', value: eur(factura.total_cents) });
  return rows;
}

function InvoicePdf({ factura, empresa, settings }: { factura: any; empresa: any; settings?: any }) {
  const rectification = isRectification(factura);
  const primaryColor = rectification
    ? '#dc2626'
    : (settings?.theme_color || empresa?.theme_color || '#4f46e5');
  const lines = Array.isArray(factura.lines) ? factura.lines : [];
  const totals = buildTotals(factura);
  const qrUri = factura.__qr_data_uri as string | undefined;
  const logoUri = factura.__logo_data_uri as string | null | undefined;

  const white = '#ffffff';

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Cabecera */}
        <View style={{ ...styles.header, backgroundColor: primaryColor }}>
          <View>
            {logoUri && <Image src={{ uri: logoUri }} style={styles.logo} />}
            <Text style={{ ...styles.headerLabel, color: white }}>{empresa?.name || 'FacturON'}</Text>
            <Text style={{ ...styles.headerMeta, color: '#f1f5f9' }}>
              NIF: {empresa?.tax_id || '-'} · {empresa?.address || ''}
            </Text>
          </View>
          <View style={styles.headerRight}>
            <Text style={{ ...styles.headerLabel, color: white, fontSize: rectification ? 14 : 20 }}>
              {rectification ? 'FACTURA RECTIFICATIVA' : 'FACTURA'}
            </Text>
            <Text style={{ ...styles.headerMeta, color: '#f1f5f9' }}>
              Nº: {factura.formatted_number}
            </Text>
            <Text style={{ ...styles.headerMeta, color: '#f1f5f9' }}>
              Fecha: {fmtDate(factura.issued_at)}
            </Text>
            {factura.due_date && (
              <Text style={{ ...styles.headerMeta, color: '#f1f5f9' }}>
                Vence: {fmtDate(factura.due_date)}
              </Text>
            )}
          </View>
        </View>

        {rectification && (
          <View style={styles.rectBox}>
            <View>
              <Text style={styles.rectTitle}>Documento de Rectificación (RD 1619/2012)</Text>
              <Text style={styles.rectText}>
                <Text style={{ fontWeight: 'bold' }}>Motivo: </Text>
                {factura.rectification_reason || 'R1 - Error fundado en derecho / rectificación de importes'}
              </Text>
            </View>
          </View>
        )}

        {/* Cliente */}
        <View style={{ ...styles.clientBox, borderLeftColor: primaryColor }}>
          <View>
            <Text style={styles.clientLabel}>FACTURAR A:</Text>
            <Text style={styles.clientName}>{factura.client_name || 'Cliente General'}</Text>
            <Text style={styles.clientMeta}>NIF/CIF: {factura.client_tax_id || '-'}</Text>
            {factura.client_address && (
              <Text style={styles.clientMeta}>{factura.client_address}</Text>
            )}
          </View>
        </View>

        {/* Conceptos */}
        <View style={styles.table}>
          <View style={{ flexDirection: 'row', backgroundColor: primaryColor, borderRadius: 2 }}>
            <Text style={{ ...styles.th, width: '44%' }}>CONCEPTO</Text>
            <Text style={{ ...styles.th, ...styles.thC, width: '10%' }}>CANT.</Text>
            <Text style={{ ...styles.th, ...styles.thR, width: '16%' }}>PRECIO UD.</Text>
            <Text style={{ ...styles.th, ...styles.thC, width: '10%' }}>I.V.A.</Text>
            <Text style={{ ...styles.th, ...styles.thR, width: '20%' }}>TOTAL</Text>
          </View>
          {lines.length === 0 ? (
            <View style={{ padding: 8 }}>
              <Text style={{ fontSize: 9, color: '#94a3b8', textAlign: 'center' }}>
                Sin conceptos registrados
              </Text>
            </View>
          ) : (
            lines.map((l: any, idx: number) => (
              <View key={idx} style={{ flexDirection: 'row' }}>
                <Text style={{ ...styles.td, width: '44%' }}>{l.description}</Text>
                <Text style={{ ...styles.td, ...styles.tdC, ...styles.tdMut, width: '10%' }}>
                  {Number(l.quantity || 1).toFixed(2)}
                </Text>
                <Text style={{ ...styles.td, ...styles.tdR, ...styles.tdMut, width: '16%' }}>
                  {eur(l.unit_price_cents)}
                </Text>
                <Text style={{ ...styles.td, ...styles.tdC, ...styles.tdMut, width: '10%' }}>
                  {Number(l.vat_percent || 0) > 0 ? `${Number(l.vat_percent)}%` : '—'}
                </Text>
                <Text style={{ ...styles.td, ...styles.tdR, ...styles.tdBold, width: '20%' }}>
                  {eur(l.total_amount_cents)}
                </Text>
              </View>
            ))
          )}
        </View>

        {/* Totales */}
        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginBottom: 14 }}>
          <View style={{ width: '42%' }}>
            {totals.map((row, i) => {
              const isTotal = row.label === 'TOTAL';
              return (
                <View
                  key={i}
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingVertical: 1.5,
                    paddingHorizontal: 4,
                    borderTopWidth: isTotal ? 1.5 : 0,
                    borderTopColor: primaryColor,
                  }}
                >
                  <Text
                    style={{
                      fontSize: isTotal ? 11 : 9,
                      fontWeight: isTotal ? 'bold' : 'normal',
                      color: isTotal ? primaryColor : '#64748b',
                    }}
                  >
                    {row.label}:
                  </Text>
                  <Text
                    style={{
                      fontSize: isTotal ? 12 : 9,
                      fontWeight: 'bold' as any,
                      color: isTotal ? primaryColor : '#0f172a',
                    }}
                  >
                    {row.value}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Pie Veri*factu + QR */}
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'flex-end',
            borderTopWidth: 1,
            borderTopColor: '#e2e8f0',
            paddingTop: 8,
          }}
        >
          <View style={{ width: '78%', paddingRight: 10 }}>
            <Text style={{ fontSize: 9, fontWeight: 'bold', color: '#334155', marginBottom: 2 }}>
              Factura Verificada (Veri*factu)
            </Text>
            <Text style={{ fontSize: 7.5, color: '#64748b', lineHeight: 1.35 }}>
              Emitido al amparo del Reglamento que regula los requisitos de los sistemas informáticos de
              facturación (Real Decreto 1007/2023).
            </Text>
            <Text style={{ fontSize: 8, color: primaryColor, fontWeight: 'bold', marginTop: 3 }}>
              Generado de forma segura con FacturON
            </Text>
          </View>
          {qrUri ? (
            <Image src={{ uri: qrUri }} style={{ width: 44, height: 44 }} />
          ) : (
            <View
              style={{
                width: 44,
                height: 44,
                borderWidth: 1,
                borderColor: '#cbd5e1',
                borderStyle: 'dashed',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text style={{ fontSize: 6, color: '#94a3b8' }}>QR</Text>
            </View>
          )}
        </View>
      </Page>
    </Document>
  );
}

// ─────────────────────────────────────────────────────────────
// Public API (server-only)
// ─────────────────────────────────────────────────────────────

export interface InvoicePdfInput {
  factura: any;
  empresa: any;
  settings?: any;
}

/**
 * Renderiza el PDF (Buffer). Monta el logo y el QR como data URIs locales y
 * devuelve un Buffer listo para base64. Nunca depende de html2canvas/CDN.
 */
export async function renderInvoicePdfBuffer({
  factura,
  empresa,
  settings,
}: InvoicePdfInput): Promise<Buffer> {
  const facturaForPdf = {
    ...factura,
    __logo_data_uri: await embedLogo(settings?.logo_url || empresa?.logo_url),
    __qr_data_uri: await buildQrDataUri(factura?.qr_code_url),
  };

  // `renderToBuffer` acepta un elemento React; se renderiza dentro del
  // propio watchdog de @react-pdf (sin timers que cuelguen al navegador).
  return renderToBuffer(
    <InvoicePdf factura={facturaForPdf} empresa={empresa} settings={settings} />
  );
}